package com.Customer.orders.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Customer.orders.dto.GetAllCustomers;
import com.Customer.orders.entity.Customers;

@Repository
public interface CustomerRepo extends JpaRepository<Customers,Long> {
	
	@Query("SELECT tbl FROM Customers tbl")
    public List<GetAllCustomers> getAllCustomers();
}
