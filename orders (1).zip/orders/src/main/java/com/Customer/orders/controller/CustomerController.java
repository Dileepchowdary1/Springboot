package com.Customer.orders.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Customer.orders.dto.CreateCustomerDto;
import com.Customer.orders.dto.ResponseDto;
import com.Customer.orders.entity.Customers;
import com.Customer.orders.service.CustomerService;

@RestController
@RequestMapping("Customer/")
public class CustomerController {
	
	public static final Logger logger = LogManager.getLogger(CustomerController.class);
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping(path = "createCustomers", produces = {"application/json", "application/xml"})
    public ResponseEntity<Customers> saveCustomer(@RequestBody CreateCustomerDto customerDto) {
        try {
            logger.info("{} >> customerDto:[{}],", customerDto);
            Customers cResponse = customerService.saveCustomer(customerDto);
            logger.info("{} << cResponse:[{}]", cResponse);
            return new ResponseEntity<>(cResponse, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Error saving customer", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/fetchcustomer/{customerId}")
    public ResponseEntity<ResponseDto> fetchCustomerwithEligibilityAndWthOutEligibility(@PathVariable("customerId") Long customerId) {
        try {
            String message = customerService.fetchCustomerById(customerId);
            logger.info("costomers:{}", message);
            ResponseDto responseDto = new ResponseDto(message);
            return ResponseEntity.status(HttpStatus.OK).body(responseDto);
        } catch (Exception e) {
            logger.error("Exception:{}", e.getMessage());
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseDto());
        }
    }
	

}
