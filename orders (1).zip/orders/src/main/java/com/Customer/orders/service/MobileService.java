package com.Customer.orders.service;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Customer.orders.dto.MobileDto;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.repository.MobileRepo;

@Service
public class MobileService {
	
	public static final Logger logger = LogManager.getLogger(MobileService.class);
	
	@Autowired
	MobileRepo mobileRepository;
	
	public Mobile saveMobiles(MobileDto dto) {
		try {
			logger.info("Saving mobile with name: {} and price: {}", dto.getMobileName(), dto.getMobilePrice());
			Mobile mobile=new Mobile();
			mobile.setMobileName(dto.getMobileName());
			mobile.setMobilePrice(dto.getMobilePrice());
			Mobile mobileResposne=mobileRepository.save(mobile);
			 
		return mobileResposne;
		} catch (Exception e) {
			e.printStackTrace();
			return new Mobile();
		}
	}
}
