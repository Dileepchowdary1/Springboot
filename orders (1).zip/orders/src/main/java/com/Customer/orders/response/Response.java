package com.Customer.orders.response;

public class Response {
	
	private boolean status;
    private int statusCode;
    private String messages;

    public Response() {
		super();
	}

	public Response(boolean status, String messages) {
        this.status = status;
        this.messages = messages;
    }

   

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessages() {
		return messages;
	}

	public void setMessages(String messages) {
		this.messages = messages;
	}
	 @Override
	    public String toString() {
	        return "" + "status=" + status + ", statusCode=" + statusCode + ", messages=" + messages ;
	    }
}
