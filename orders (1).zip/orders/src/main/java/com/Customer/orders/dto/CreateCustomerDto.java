package com.Customer.orders.dto;

public class CreateCustomerDto {
	
	private String customerName;
	private String customerAddress;
	private int customerCreditScore;
	public CreateCustomerDto() {
		super();
	}
	public CreateCustomerDto(String customerName, String customerAddress,int customerCreditScore) {
		super();
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.customerCreditScore=customerCreditScore;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getCustomerCreditScore() {
		return customerCreditScore;
	}
	public void setCustomerCreditScore(int customerCreditScore) {
		this.customerCreditScore = customerCreditScore;
	}
	@Override
	public String toString() {
		return "CreateCustomerDto [customerName=" + customerName + ", customerAddress=" + customerAddress
				+ ", customerCreditScore=" + customerCreditScore + "]";
	}

	
}
