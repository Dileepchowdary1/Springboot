package com.Customer.orders.dto;

public class MobileDto {
	
	private Long mobileId;
	private String mobileName;
	private Double mobilePrice;
	public MobileDto() {
		super();
	}
	public MobileDto(Long mobileId, String mobileName, Double mobilePrice) {
		super();
		this.mobileId = mobileId;
		this.mobileName = mobileName;
		this.mobilePrice = mobilePrice;
	}
	public Long getMobileId() {
		return mobileId;
	}
	public void setMobileId(Long mobileId) {
		this.mobileId = mobileId;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public Double getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(Double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	@Override
	public String toString() {
		return "MobileDto [mobileId=" + mobileId + ", mobileName=" + mobileName + ", mobilePrice=" + mobilePrice + "]";
	}
	
	

}
