package com.Customer.orders.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Customer.orders.entity.Mobile;

@Repository
public interface MobileRepo extends JpaRepository<Mobile,Long>{
	

}
