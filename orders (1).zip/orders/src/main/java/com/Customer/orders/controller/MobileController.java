package com.Customer.orders.controller;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Customer.orders.dto.MobileDto;
import com.Customer.orders.entity.Mobile;
import com.Customer.orders.service.MobileService;

@RestController
@RequestMapping("mobiles/")
public class MobileController {
	
public static final Logger logger = LogManager.getLogger(MobileController.class);
	
	@Autowired
	MobileService mobileService;
	
	@PostMapping(path = "addmobiles",produces = {"application/json", "application/xml"})
	public ResponseEntity<Mobile> saveMobile(@RequestBody MobileDto mobileDto) {
		try {
			 logger.info("{} >> mobileDto:[{}],", mobileDto);
			Mobile mobile=mobileService.saveMobiles(mobileDto);
			logger.info(">>save:mobile:[{}]", mobile);
			return new ResponseEntity<>(mobile, HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error saving customer", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
